Author: CodexWorld
Author URL: http://www.codexworld.com
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/paypal-payment-gateway-integration-in-codeigniter/

============ Instruction ============
1. Place the "assets" directory at the root directory of your application.
2. Take all the files from directories of the "application" directory and place into the respective directory on your application directory.
3. Open the "application/config/paypallib_config.php" file => Change the "business" configuration value with your PayPal business email.
4. Browse the Products controller on the browser and test the functionality.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/paypal-payment-gateway-integration-in-codeigniter/#respond. We will reply your query ASAP.
