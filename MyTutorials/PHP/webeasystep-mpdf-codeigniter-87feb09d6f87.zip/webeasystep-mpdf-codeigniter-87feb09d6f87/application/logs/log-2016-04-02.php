<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-02 16:01:33 --> Severity: Notice --> Undefined index: config C:\xampp\htdocs\demo\system\core\Loader.php 1324
ERROR - 2016-04-02 16:39:23 --> 404 Page Not Found: /index
ERROR - 2016-04-02 16:40:24 --> 404 Page Not Found: /index
ERROR - 2016-04-02 16:40:43 --> Query error: Table 'demo.d_ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `d_ci_sessions`
WHERE `id` = '3eaf3b828434245b5f9088d4ee9471fd43e758f6'
ERROR - 2016-04-02 17:07:40 --> 404 Page Not Found: /index
DEBUG - 2016-04-02 17:08:36 --> No URI present. Default controller set.
ERROR - 2016-04-02 17:08:37 --> Severity: error --> Exception: C:\xampp\htdocs\codeigniter_demo\application\models/Phpword_model.php exists, but doesn't declare class Phpword_model C:\xampp\htdocs\codeigniter_demo\system\core\Loader.php 336
DEBUG - 2016-04-02 17:09:00 --> No URI present. Default controller set.
ERROR - 2016-04-02 17:09:01 --> Query error: Table 'demo.d_ci_news' doesn't exist - Invalid query: SELECT *
FROM `d_ci_news`
DEBUG - 2016-04-02 17:09:23 --> No URI present. Default controller set.
ERROR - 2016-04-02 17:09:24 --> Query error: Table 'demo.falsed_ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `FALSEd_ci_sessions`
WHERE `id` = '45d489ab8ddc443d6fdd58858854469176c59ee3'
DEBUG - 2016-04-02 17:10:01 --> No URI present. Default controller set.
ERROR - 2016-04-02 17:10:02 --> Query error: Table 'demo.falsed_ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `FALSEd_ci_sessions`
WHERE `id` = '45d489ab8ddc443d6fdd58858854469176c59ee3'
DEBUG - 2016-04-02 17:10:14 --> No URI present. Default controller set.
ERROR - 2016-04-02 17:10:16 --> Query error: Table 'demo.d_ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `d_ci_sessions`
WHERE `id` = '45d489ab8ddc443d6fdd58858854469176c59ee3'
DEBUG - 2016-04-02 17:11:06 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:11:31 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:15:45 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:16:34 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:17:37 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:19:04 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:19:23 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:21:42 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:22:27 --> No URI present. Default controller set.
ERROR - 2016-04-02 17:22:31 --> Severity: Warning --> Missing argument 1 for Phpword::download() C:\xampp\htdocs\codeigniter_demo\application\controllers\Phpword.php 17
ERROR - 2016-04-02 17:22:31 --> Severity: Notice --> Undefined variable: news C:\xampp\htdocs\codeigniter_demo\application\controllers\Phpword.php 31
ERROR - 2016-04-02 17:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\codeigniter_demo\application\controllers\Phpword.php 31
DEBUG - 2016-04-02 17:23:48 --> No URI present. Default controller set.
DEBUG - 2016-04-02 17:57:48 --> No URI present. Default controller set.
DEBUG - 2016-04-02 20:15:22 --> No URI present. Default controller set.
ERROR - 2016-04-02 20:15:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'webeasys_admin'@'localhost' (using password: YES) C:\xampp\htdocs\codeigniter_demo\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-04-02 20:15:23 --> Severity: error --> Exception: Unable to connect to the database. C:\xampp\htdocs\codeigniter_demo\system\database\DB_driver.php 433
DEBUG - 2016-04-02 20:15:48 --> No URI present. Default controller set.
ERROR - 2016-04-02 20:15:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'webeasys_admin'@'localhost' (using password: YES) C:\xampp\htdocs\codeigniter_demo\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-04-02 20:15:49 --> Severity: error --> Exception: Unable to connect to the database. C:\xampp\htdocs\codeigniter_demo\system\database\DB_driver.php 433
DEBUG - 2016-04-02 20:16:09 --> No URI present. Default controller set.
DEBUG - 2016-04-02 20:33:43 --> Phpword class already loaded. Second attempt ignored.
DEBUG - 2016-04-02 20:34:21 --> Phpword class already loaded. Second attempt ignored.
DEBUG - 2016-04-02 20:34:32 --> Phpword class already loaded. Second attempt ignored.
DEBUG - 2016-04-02 20:54:56 --> No URI present. Default controller set.
DEBUG - 2016-04-02 20:55:25 --> No URI present. Default controller set.
DEBUG - 2016-04-02 20:59:15 --> No URI present. Default controller set.
