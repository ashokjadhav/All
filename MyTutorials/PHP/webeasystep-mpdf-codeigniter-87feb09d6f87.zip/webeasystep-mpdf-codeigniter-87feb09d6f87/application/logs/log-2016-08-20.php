<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-20 19:51:51 --> 404 Page Not Found: /index
ERROR - 2016-08-20 19:52:23 --> 404 Page Not Found: /index
DEBUG - 2016-08-20 19:52:49 --> No URI present. Default controller set.
ERROR - 2016-08-20 19:52:50 --> Unable to load the requested class: Pdf
DEBUG - 2016-08-20 19:53:23 --> No URI present. Default controller set.
ERROR - 2016-08-20 19:53:23 --> Unable to load the requested class: Pdf
DEBUG - 2016-08-20 19:53:45 --> No URI present. Default controller set.
ERROR - 2016-08-20 19:53:45 --> Unable to load the requested class: PDF
DEBUG - 2016-08-20 19:53:52 --> No URI present. Default controller set.
ERROR - 2016-08-20 19:53:52 --> Unable to load the requested class: Pdf
DEBUG - 2016-08-20 19:54:13 --> No URI present. Default controller set.
ERROR - 2016-08-20 19:54:13 --> Unable to load the requested class: Pdf
DEBUG - 2016-08-20 19:55:21 --> No URI present. Default controller set.
DEBUG - 2016-08-20 19:55:21 --> mPDF class is loaded.
ERROR - 2016-08-20 19:55:21 --> Severity: Notice --> Undefined property: Mpdf::$Pdf C:\xampp\htdocs\mpdf_codeigniter\application\controllers\Mpdf.php 18
DEBUG - 2016-08-20 19:55:39 --> No URI present. Default controller set.
DEBUG - 2016-08-20 19:55:39 --> mPDF class is loaded.
DEBUG - 2016-08-20 19:56:28 --> No URI present. Default controller set.
DEBUG - 2016-08-20 19:56:28 --> mPDF class is loaded.
DEBUG - 2016-08-20 19:58:08 --> No URI present. Default controller set.
DEBUG - 2016-08-20 19:58:09 --> mPDF class is loaded.
ERROR - 2016-08-20 19:58:09 --> Severity: Notice --> Undefined variable: news C:\xampp\htdocs\mpdf_codeigniter\application\views\content\mpdf.php 16
ERROR - 2016-08-20 19:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mpdf_codeigniter\application\views\content\mpdf.php 16
ERROR - 2016-08-20 19:58:09 --> Severity: Notice --> Undefined variable: pdf C:\xampp\htdocs\mpdf_codeigniter\application\controllers\Mpdf.php 25
DEBUG - 2016-08-20 19:58:45 --> No URI present. Default controller set.
DEBUG - 2016-08-20 19:58:45 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:00:49 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:00:49 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:00:51 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:00:51 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:00:51 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:00:51 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:04:30 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:04:30 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:05:29 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:05:29 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:11:06 --> No URI present. Default controller set.
ERROR - 2016-08-20 20:11:06 --> 404 Page Not Found: Mpdf/index
ERROR - 2016-08-20 20:11:29 --> 404 Page Not Found: /index
DEBUG - 2016-08-20 20:11:46 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:11:47 --> mPDF class is loaded.
ERROR - 2016-08-20 20:11:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mpdf_codeigniter\application\views\content\mpdf.php 16
ERROR - 2016-08-20 20:11:48 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:48 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:49 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:50 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 96
ERROR - 2016-08-20 20:11:51 --> Severity: 8192 --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\includes\functions.php 97
ERROR - 2016-08-20 20:11:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mpdf_codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\mpdf.php 7447
ERROR - 2016-08-20 20:11:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mpdf_codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\mpdf_codeigniter\application\third_party\mpdf\mpdf.php 1736
DEBUG - 2016-08-20 20:19:49 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:19:49 --> mPDF class is loaded.
ERROR - 2016-08-20 20:19:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mpdf_codeigniter\application\views\content\mpdf.php 16
DEBUG - 2016-08-20 20:19:51 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:19:51 --> mPDF class is loaded.
ERROR - 2016-08-20 20:19:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mpdf_codeigniter\application\views\content\mpdf.php 16
DEBUG - 2016-08-20 20:24:21 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:24:22 --> mPDF class is loaded.
ERROR - 2016-08-20 20:24:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mpdf_codeigniter\application\views\content\mpdf.php 19
DEBUG - 2016-08-20 20:24:22 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:24:22 --> mPDF class is loaded.
ERROR - 2016-08-20 20:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mpdf_codeigniter\application\views\content\mpdf.php 19
DEBUG - 2016-08-20 20:25:30 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:25:30 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:25:31 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:25:31 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:26:02 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:26:02 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:26:03 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:26:04 --> mPDF class is loaded.
DEBUG - 2016-08-20 20:34:56 --> No URI present. Default controller set.
DEBUG - 2016-08-20 20:34:56 --> mPDF class is loaded.
