<?php

$lang['pages']    = "الصفحات الإضافية";
$lang['contactus']    = "اتصل بنا";
$lang['contactus'] = 'إدارة الرسائل';
$lang['my_account'] = 'حسابى';
$lang['home'] = 'الرئيسية';
$lang['modify_my_info'] = ' تعديل بيناتى';
$lang['logout'] = 'تسجيل الخروج';
$lang['welcome'] = 'مرحبا بك يا';
$lang['currency'] =  "ريال سعودى";
$lang['manage_back_end'] = "لوحة التحكم";