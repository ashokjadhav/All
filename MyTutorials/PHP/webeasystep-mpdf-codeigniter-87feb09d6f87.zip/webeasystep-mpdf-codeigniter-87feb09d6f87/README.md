# DEMO LINK #
[codeigniter pdf generator
](http://webeasystep.com/blog/view_article/Generate_MS_Word_document_files_with_Codeigniter_and_Phpword_library)