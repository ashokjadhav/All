cat header > index.html;
markdown index.markdown >> index.html;
cat footer >> index.html;
