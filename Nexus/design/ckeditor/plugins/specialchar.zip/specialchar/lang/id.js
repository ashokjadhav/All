﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'id', {
	options: 'Opsi spesial karakter',
	title: 'Pilih spesial karakter',
	toolbar: 'Sisipkan spesial karakter'
} );
