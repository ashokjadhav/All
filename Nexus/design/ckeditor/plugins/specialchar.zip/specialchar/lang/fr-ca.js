﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'fr-ca', {
	options: 'Option des caractères spéciaux',
	title: 'Sélectionner un caractère spécial',
	toolbar: 'Insérer un caractère spécial'
} );
