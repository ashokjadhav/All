﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'zh', {
	options: '特殊字元選項',
	title: '選取特殊字元',
	toolbar: '插入特殊字元'
} );
