﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'cy', {
	options: 'Opsiynau Nodau Arbennig',
	title: 'Dewis Nod Arbennig',
	toolbar: 'Mewnosod Nod Arbennig'
} );
