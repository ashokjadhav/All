﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'sq', {
	options: 'Mundësitë për Karaktere Speciale',
	title: 'Përzgjidh Karakter Special',
	toolbar: 'Vendos Karakter Special'
} );
