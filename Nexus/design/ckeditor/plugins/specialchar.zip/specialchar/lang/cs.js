﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'cs', {
	options: 'Nastavení speciálních znaků',
	title: 'Výběr speciálního znaku',
	toolbar: 'Vložit speciální znaky'
} );
