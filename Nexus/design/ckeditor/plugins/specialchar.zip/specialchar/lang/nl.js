﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'nl', {
	options: 'Speciale tekens opties',
	title: 'Selecteer speciaal teken',
	toolbar: 'Speciaal teken invoegen'
} );
